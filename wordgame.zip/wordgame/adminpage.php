<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" type="text/css" href="css/admin.css"/>
    <title>ADMIN::PAGE</title>

    <style>
        body {
            background-size: cover;
            background-image: url(image/background.jpg);
            background-repeat: no-repeat;
            background-position: center top;
            margin: 0%;
            background-attachment: fixed;
        }
    </style>

</head>

<body>
    <?php
        require("mysql/connection.php");
        echo '<meta http-equiv="content-type" content="text/html; charset=utf-8">';
    ?>
    <div class="DataTable">
        <?php
            $sql = "SELECT * FROM userinfo WHERE authority=0";
            $res = mysqli_query($conn,$sql);

            while($thread = mysqli_fetch_assoc($res)){
                $result[] = $thread;
            }

            if($result){
                echo '<table><tr><td>username</td><td>password</td></tr>';
                foreach($result as $val){
                    echo '<tr><td>'.$val['username'].'</td><td>'.$val['password'].'</td></tr>';
                }
                echo '</table>';
            }
        ?>
    </div>

    <div class="opt">
            <form method="POST" action="mysql/delete.php">
                <input type="text" maxlength="99" placeholder="Enter the username" name="username"><br>
                <input type="submit" name="submit" value="DELETE"><br>
            </form>
            <form method="POST" action="mysql/adduser.php">
                <input type="text" maxlength="99" placeholder="Enter the username" name="username"><br>
                <input type="text" maxlength="99" placeholder="Enter the password" name="password"><br>
                <input type="submit" name="submit" value="ADD"><br>
            </form>
    </div>
        
</body>

</html>