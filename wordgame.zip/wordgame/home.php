<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" type="text/css" href="css/home.css"/>
    <title>HOME PAGE</title>

    <style>
        body {
            background-size: cover;
            background-image: url(image/background.jpg);
            background-repeat: no-repeat;
            background-position: center top;
            margin: 0%;
            background-attachment: fixed;
        }
    </style>

</head>

<body>
    <?php
        require ("mysql/session.php");
        $username = $_SESSION['username'];
    ?>
    <div class="info">
        <?php
            echo '<br><br><br><br><br><br><br>';
            echo '<p class="info_show">----~\USER/~----<br></p>';
            echo '<p class="info_show1">'.$username.'</p>';
            echo '<p class="info_show">***\----Welcome----/***<br></p>';
        ?>
        <a href="mysql/update.php">Change Password</a>
        <br>
        <a href="mysql/logout.php">Log Out</a>
    </div>
    <div class="picture">
        <form action="rungame.php">
            <div class="button">
                <input type="submit" name="submit" value="~\PLAY NOW/~">
            </div>
        </form>
    </div>
</body>

</html>