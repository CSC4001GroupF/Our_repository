<?php
    session_start();
    header("content-type:text/html;charset=utf-8");

    require("connection.php");

    $username = $_POST["username"];

    if($username){
        $sql = "SELECT * FROM userinfo where username='$username'";
        $ret = mysqli_query($conn,$sql);
        $row = $ret->num_rows;
        if($row){
            $sql = "DELETE FROM userinfo where username='$username'";
            $ret1 = mysqli_query($conn,$sql);
            if($ret1){
                echo "<script language='javascript' type='text/javascript'>";
                echo "alert('Delete success!')";
                echo "</script>";
                echo "<script language='javascript' type='text/javascript'>";
                echo "window.location.href = '../adminpage.php'";
                echo "</script>";
            }
            else{
                echo "<script language='javascript' type='text/javascript'>";
                echo "alert('Delete failed!')";
                echo "</script>";
                echo "<script language='javascript' type='text/javascript'>";
                echo "window.location.href = '../adminpage.php'";
                echo "</script>";
            }
        }
        else{
            echo "<script language='javascript' type='text/javascript'>";
            echo "alert('Wrong username')";
            echo "</script>";
            echo "<script language='javascript' type='text/javascript'>";
            echo "window.location.href = '../adminpage.php'";
            echo "</script>";
        }
    }
    else{
        echo "<script language='javascript' type='text/javascript'>";
        echo "window.location.href='../adminpage.php'";
        echo "</script>";
    }

?>