<?php
    require("session.php");
    $username = $_SESSION["username"];
    $sql = "SELECT * FROM userinfo where username='$username'";
    $ret = mysqli_query($conn,$sql);
    $res = mysqli_fetch_array($ret);
    $password = $res[1];

    if($password!=$_REQUEST["oldpassword"]){
        ?>
        <script> 
            alert("Wrong Old Password"); 
            window.location.href="update.php"; 
        </script>
        <?php
    }

    $newpassword=$_REQUEST["newpassword"];
    $repassword=$_REQUEST["repassword"];
    ?>
    <?php
    if($newpassword!=$repassword){
        ?>
        <script> 
            alert("Inconsistent passwords!"); 
            window.location.href="update.php"; 
        </script>
        <?php
    }
    $ID = $res[0];
    if($newpassword){
        $newpassword=$newpassword;//????
        $sql = "UPDATE userinfo set password='$newpassword' where username='$ID'";
        $ret = mysqli_query($conn,$sql);
    }
    ?>
    <script> 
        alert("Password Updated!"); 
        window.location.href="../home.php"; 
    </script>