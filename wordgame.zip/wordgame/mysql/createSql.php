<?php
    require("connection.php");

    if(!$conn){
        die("Connection failed:".mysqli_error($conn));
    }

    $table = "userinfo"; // user information 
    $drop_sql = "DROP TABLE IF EXISTS $table";
    $sql = "CREATE TABLE $table(
            username VARCHAR(50) NOT NULL PRIMARY KEY,
            password VARCHAR(50) NOT NULL,
            token VARCHAR(50) NOT NULL,
            token_exptime INT(10) NOT NULL,
            status TINYINT(1) NOT NULL DEFAULT '0',
            regtime TIMESTAMP NOT NULL,
            authority TINYINT(1) NOT NULL DEFAULT '0'
            )";

    mysqli_query($conn,$drop_sql);
    if(mysqli_query($conn,$sql)){
        echo "Table $table created successfully".PHP_EOL;
    }
    else{
        echo "Table $table created failed";
    }

    // $table = "usergame"; // user game related information
    // $drop_sql = "DROP TABLE IF EXISTS $table";
    // $sql = "CREATE TABLE $table(
    //         username VARCHAR(50) NOT NULL PRIMARY KEY,
    //         gpd VARCHAR(50) NOT NULL
    //         )";

    // mysqli_query($conn,$drop_sql);
    // if(mysqli_query($conn,$sql)){
    //     echo "Table $table created successfully".PHP_EOL;
    // }
    // else{
    //     echo "Table $table created failed";
    // }

    $username = "admin";
    $password = "admin123";
    $token = "NAN";
    $token_exptime = "NAN";
    $regtime = "NAN";
    $sql = "INSERT INTO userinfo(username,password,token,token_exptime,status,regtime,authority)
            VALUES('$username','$password','$token','$token_exptime',1,'$regtime',1)";
    if(mysqli_query($conn,$sql)){
        echo "Admin account create successfully".PHP_EOL;
    }
    else{
        echo "Admin account create failed";
    }
    
    mysqli_close($conn);
?>
