<?php
    require("connection.php");
    $verify = stripslashes(trim($_GET['verify']));
    $nowtime = time();
    $sql = "SELECT username,token_exptime FROM userinfo WHERE status='0' AND token='$verify'";
    $query = mysqli_query($conn,$sql);
    $row = mysqli_fetch_array($query);
    if($row){
        if($nowtime>$row['token_exptime']){
            $msg = "Your activation has expired.
                    Please log in to your account and send an activation email again";
        }
        else{
            $username = $row['username'];
            $sql = "UPDATE userinfo SET status=1 WHERE username='$username'";
            mysqli_query($conn,$sql);
            // if(mysqli_affected_rows($link)!=1)die(0);
            $msg = "Activation success!";
        }
    }
    else{
        $msg = 'error';
    }
    echo $msg;
?>