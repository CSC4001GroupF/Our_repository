<?php

    header("Content-Type: text/html; charset=utf-8");

    require("stmp.php");

    function sendMail($to,$title,$content){
        //使用163邮箱服务器
        $smtpserver = "smtp.163.com";

        //163邮箱服务器端口
        $smtpserverport = 25;

        //你的163服务器邮箱账号
        $smtpusermail = "worldgame_official@163.com";
        //收件人邮箱
        $smtpemailto = $to;

        //你的邮箱账号(去掉@163.com)
        $smtpuser = "worldgame_official";//你的163邮箱去掉后面的163.com
        //你的邮箱密码
        $smtppass = "EXFPGSYTULKDTBRD"; //你的163邮箱SMTP的授权码，千万不要填密码！！！

        //邮件主题
        $mailsubject = $title;
        //邮件内容
        $mailbody = $content;
        //邮件格式（HTML/TXT）,TXT为文本邮件
        $mailtype = "HTML";
        //这里面的一个true是表示使用身份验证,否则不使用身份验证.
        $smtp = new Smtp($smtpserver,$smtpserverport,true,$smtpuser,$smtppass);
        //是否显示发送的调试信息
        $smtp->debug = false;
        //发送邮件
        $state = $smtp->sendmail($smtpemailto, $smtpusermail, $mailsubject, $mailbody, $mailtype);

        echo "<div style='width:300px; margin:36px auto;'>";
        if($state==""){
            echo "Message sending failed! Please check whether the email address is correct.";
            exit();
        }
    }
?>