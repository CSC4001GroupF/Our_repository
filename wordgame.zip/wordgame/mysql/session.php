<?php
    session_start();
    if (isset ( $_SESSION ["login"] )) {
        require("connection.php");
    }else{
        ?>
        <script>
            alert("Log In first!");
            window.location.href="index.html";
        </script>
    <?php
    }
?>