<?php 
    session_start();
    header("content-type:text/html;charset=utf-8");

    require("connection.php");

    $username = $_POST["username"];
    $password = $_POST["password"];
    if($username && $password){
        $sql = "SELECT * FROM userinfo where username='$username' and password='$password'";
        $ret = mysqli_query($conn,$sql);
        $row = $ret->num_rows;
        if($row){
            $row2 = mysqli_fetch_array($ret);
            $status = $row2['status'];
            $autority = $row2['authority'];
            if($status){
                $_SESSION['username'] = $username;
                $_SESSION['password'] = $password;
                $_SESSION['login'] = mt_rand(0,100000);
                if($autority){
                    header("refresh:0;url=../adminpage.php");
                    exit;
                }
                else{
                    header("refresh:0;url=../home.php");
                    exit;
                }
            }
            else{
                echo "<script language='javascript' type='text/javascript'>";
                echo "alert('Pleace Activate Your Account First!')";
                echo "</script>";
                echo "<script language='javascript' type='text/javascript'>";
                echo "window.location.href = '../index.html'";
                echo "</script>";
            }
        }
        else{
            echo "<script language='javascript' type='text/javascript'>";
            echo "alert('Wrong username or password!')";
            echo "</script>";
            echo "<script language='javascript' type='text/javascript'>";
            echo "window.location.href = '../index.html'";
            echo "</script>";
        }
    }
    else{
        echo "<script language='javascript' type='text/javascript'>";
        echo "window.location.href='../index.html'";
        echo "</script>";
    }
?>