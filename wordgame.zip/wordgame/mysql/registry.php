<?php
    require("connection.php");
    // require("email.php");
    // require("stmp.class.php");
    require("sendEmail.php");

    header("content-type:text/html;charset=utf-8");

    $username = $_POST["username"];
    $password = $_POST["password"];

    if(!$username || !$password){
        echo "<script language='javascript' type='text/javascript'>";
        echo "window.location.href='../registry.html'";
        echo "</script>";
    } // exsit empty messages
    else{
        $select_sql = "SELECT * FROM userinfo WHERE username = '$username'";
        $ret = mysqli_query($conn,$select_sql);
        $row = mysqli_num_rows($ret);
        if($row == 1){
            echo "Username Existed!";
            ?>
            <script type="text/javascript"> 
                // alert("user existed"); 
                window.location.href="../registry.html"; 
            </script>
        <?php
            exit;
        } // Already registried this email

        $match_res = preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$username);

        if(!$match_res){
            ?>
            <script type="text/javascript"> 
                alert("Wrong Format of Username"); 
                window.location.href="../registry.html"; 
            </script>
            <?php
        } // Wrong format of username(Email)
        else{
            $regtime = time();
            $token = md5($username.$password.$regtime);
            $token_exptime = time() + 60*60*24; // 24h
            $sql = "INSERT INTO userinfo(username,password,token,token_exptime,regtime)
                    VALUES('$username','$password','$token','$token_exptime','$regtime')";  
            // $sql = "INSERT INTO userinfo(username,password) VALUES('$username','$password')";
            $res1 = mysqli_query($conn,$sql);
            // $gpd = "To Be DONE";
            // $sql = "INSERT INTO usergame(username,gpd) VALUES('$username','$gpd')";
            // $res2 = mysqli_query($conn,$sql);
            
            if($res1){
                $smtpemailto = $username;
                $emailsubject = "Activate your account";
                $emailbody = "Dear Player: Thanks for registering a new account.<br>
                            Please CLICK the link to activate your account:<br>
                            <a href='http://localhost/PhpStudy/mysql/active.php?verify=".$token."' 
                            target='_blank'>http://localhost/PhpStudy/mysql/active.php?verify=".$token."</a><br>
                            If the above link cannot be clicked, please copy it to your browser address bar for access, 
                            the link will be valid for 24 hours";
                sendMail($smtpemailto,$emailsubject,$emailbody);
            ?>
                <script type="text/javascript"> 
                    alert("Registry Success! Log In Now!"); 
                    window.location.href="../index.html"; 
                </script> 
            <?php
            }
            
        } // Right format! [Main Part!!!!]
    }
?>