<?php
    session_start();
    header("content-type:text/html;charset=utf-8");

    require("connection.php");

    $username = $_POST["username"];
    $password = $_POST["password"];

    if($username && $password){
        $regtime = time();
        $token = md5($username.$password.$regtime);
        $token_exptime = time() + 60*60*24; // 24h
        $sql = "INSERT INTO userinfo(username,password,token,token_exptime,regtime,status)
                VALUES('$username','$password','$token','$token_exptime','$regtime',1)";
        $res1 = mysqli_query($conn,$sql);
        if($res1){
            echo "<script language='javascript' type='text/javascript'>";
            echo "alert('ADD success!')";
            echo "</script>";
            echo "<script language='javascript' type='text/javascript'>";
            echo "window.location.href = '../adminpage.php'";
            echo "</script>";
        }
        else{
            echo "<script language='javascript' type='text/javascript'>";
            echo "alert('ADD failed!')";
            echo "</script>";
            echo "<script language='javascript' type='text/javascript'>";
            echo "window.location.href = '../adminpage.php'";
            echo "</script>";
        }
    }
    else{
        echo "<script language='javascript' type='text/javascript'>";
        echo "alert('Username and password can not be empty!')";
        echo "</script>";
        echo "<script language='javascript' type='text/javascript'>";
        echo "window.location.href='../adminpage.php'";
        echo "</script>";
    }

?>