<?php 

    $conn  = mysqli_connect('localhost', 'root', '', 'wordgame', 3306);
    // var_dump($conn);

    // if($conn){
    //     mysqli_query($conn,'set names utf8');
    //     $sql = "INSERT INTO userinfo(username,password) VALUES('student3','987654321')";
    //     $result = mysqli_query($conn,$sql);
    //     // var_dump($result);
    // }
    // else{
    //     echo 'Connect mysql failed';
    // }

?>