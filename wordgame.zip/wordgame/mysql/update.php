<link href="../css/update.css" rel="stylesheet" type="text/css">

<?php
    require("session.php");
?>

<body>
    <div class="update_div">
        <form action="upinsert.php" method="POST">
            <h1>Change your Password</h1>
            <input class="update_text" type="password" name="oldpassword" placeholder="Old Password">
            <input class="update_text" type="password" name="newpassword" placeholder="New Password">
            <input class="update_text" type="password" name="repassword" placeholder="Cofirm Password">
            <input class="update btn" type="submit" value="Confirm Changes">
            <a href="../home.php">Return to HOME</a>
        </form>
    </div>
</body>