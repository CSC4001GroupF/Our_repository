********[NOTECE!!! VERY IMPORTANT!!!!!]********

Before start to run the index.html, you need to create a schema in Mysql named "wordgame" first!!!!!!!! Then run createSql.php in mysql folder to create tables in sql.

After doing these operation, you can test this project!

[Notice]: username must be a legal email address. If not, you can not receive the acvative email, then you can not log in!!!

[Notice]: If you can not run the .html.exe (which means the word game exe), you may have to install GoDot Engine.